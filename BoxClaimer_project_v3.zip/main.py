# -*- coding: utf-8 -*-
import json
import os

from kivy.app import App
from kivy.clock import Clock, mainthread
from kivy.core.window import Window
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.uix.textinput import TextInput
from kivy.utils import platform

from core import Watcher, parse_cookie

UA = ("Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36")

if platform == "android":
    from jnius import autoclass
    from android.runnable import run_on_ui_thread

    PythonActivity = autoclass("org.kivy.android.PythonActivity")
    WebView = autoclass("android.webkit.WebView")
    WebViewClient = autoclass("android.webkit.WebViewClient")
    CookieManager = autoclass("android.webkit.CookieManager")
    FrameLP = autoclass("android.widget.FrameLayout$LayoutParams")
    _wv = [None]

    @run_on_ui_thread
    def show_webview(height_px):
        act = PythonActivity.mActivity
        wv = WebView(act)
        s = wv.getSettings()
        s.setJavaScriptEnabled(True)
        s.setDomStorageEnabled(True)
        s.setUserAgentString(UA)
        cm = CookieManager.getInstance()
        cm.setAcceptCookie(True)
        cm.setAcceptThirdPartyCookies(wv, True)
        wv.setWebViewClient(WebViewClient())
        act.addContentView(wv, FrameLP(-1, height_px, 48))  # 48 = Gravity.TOP
        wv.loadUrl("https://www.tiktok.com/login")
        _wv[0] = wv

    @run_on_ui_thread
    def hide_webview():
        wv = _wv[0]
        if wv is not None:
            p = wv.getParent()
            if p is not None:
                p.removeView(wv)
            wv.destroy()
            _wv[0] = None

    @run_on_ui_thread
    def keep_awake():
        PythonActivity.mActivity.getWindow().addFlags(128)  # KEEP_SCREEN_ON

    def get_cookie():
        return CookieManager.getInstance().getCookie("https://www.tiktok.com") or ""
else:
    def show_webview(h): pass
    def hide_webview(): pass
    def keep_awake(): pass
    def get_cookie(): return ""


class BoxApp(App):
    title = "Box Claimer"

    def build(self):
        self.dir = self.user_data_dir
        self.sess_path = os.path.join(self.dir, "session.json")
        self.sess = self._load(self.sess_path) or {}
        self.watcher = None
        self.login_open = False
        self.lines = []

        root = BoxLayout(orientation="vertical", padding=10, spacing=8)
        self.status = Label(text="", size_hint_y=None, height=60, font_size="16sp")
        self.handle = TextInput(hint_text="Live username (without @)", multiline=False,
                                size_hint_y=None, height=90, font_size="18sp",
                                text=self.sess.get("handle", ""))
        sv = ScrollView()
        self.logl = Label(text="", size_hint_y=None, halign="left", valign="top",
                          font_size="13sp")
        self.logl.bind(width=lambda *_: setattr(self.logl, "text_size", (self.logl.width, None)),
                       texture_size=lambda *_: setattr(self.logl, "height", self.logl.texture_size[1]))
        sv.add_widget(self.logl)
        row = BoxLayout(size_hint_y=None, height=110, spacing=8)
        self.btn_login = Button(text="Login with TikTok", font_size="16sp")
        self.btn_go = Button(text="START", font_size="18sp", bold=True)
        self.btn_login.bind(on_release=self.toggle_login)
        self.btn_go.bind(on_release=self.toggle_run)
        row.add_widget(self.btn_login)
        row.add_widget(self.btn_go)
        for w in (self.status, self.handle, sv, row):
            root.add_widget(w)
        self.refresh_status()
        keep_awake()
        return root

    # ---------- helpers
    @staticmethod
    def _load(p):
        try:
            with open(p, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return None

    def _save(self):
        with open(self.sess_path, "w", encoding="utf-8") as f:
            json.dump(self.sess, f)

    def _cfg(self):
        for p in (os.path.join(self.dir, "claim_config.json"),
                  os.path.join(os.path.dirname(os.path.abspath(__file__)),
                               "claim_config.json")):
            c = self._load(p)
            if c is not None:
                c["_dir"] = self.dir
                return c
        return {"_dir": self.dir}

    @mainthread
    def log(self, msg):
        self.lines.append(msg)
        self.lines = self.lines[-150:]
        self.logl.text = "\n".join(self.lines)

    def refresh_status(self):
        ok = bool(self.sess.get("sessionid"))
        self.status.text = "Logged in" if ok else "Not logged in"
        self.status.color = (0.3, 1, 0.4, 1) if ok else (1, 0.4, 0.4, 1)

    # ---------- login
    def toggle_login(self, *_):
        if self.login_open:
            self.close_login()
            return
        self.login_open = True
        self.btn_login.text = "Close login"
        show_webview(int(Window.height * 0.78))
        self._poll = Clock.schedule_interval(self.check_login, 1.5)

    def close_login(self):
        self.login_open = False
        self.btn_login.text = "Login with TikTok"
        try:
            self._poll.cancel()
        except Exception:
            pass
        hide_webview()

    def check_login(self, *_):
        ck = parse_cookie(get_cookie())
        if ck.get("sessionid"):
            self.sess.update(sessionid=ck["sessionid"],
                             idc=ck.get("tt-target-idc", ""),
                             cookie=get_cookie())
            self._save()
            self.close_login()
            self.refresh_status()
            self.log("Login saved.")

    # ---------- run
    def toggle_run(self, *_):
        if self.watcher:
            self.watcher.stop()
            return
        if not self.sess.get("sessionid"):
            self.log("Login first.")
            return
        h = self.handle.text.strip().lstrip("@")
        if not h:
            self.log("Enter the live username.")
            return
        self.sess["handle"] = h
        self._save()
        self.watcher = Watcher(h, self.sess, self._cfg(), self.log, self._stopped)
        self.btn_go.text = "STOP"
        self.watcher.start()
        self.log("Connecting to @%s ..." % h)

    @mainthread
    def _stopped(self):
        self.watcher = None
        self.btn_go.text = "START"
        self.log("Stopped.")


if __name__ == "__main__":
    BoxApp().run()
